function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5gfHhAk5MdW":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

